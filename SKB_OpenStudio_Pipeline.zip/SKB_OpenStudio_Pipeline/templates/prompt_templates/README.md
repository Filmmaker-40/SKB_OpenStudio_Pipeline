# Cinematic Prompt Template (16:9)

**Framing:** 16:9, full-body unless otherwise specified  
**Lighting:** dramatic, high-contrast noir for interiors; golden-hour or moonlit exteriors  
**Lens:** 35mm or 50mm equivalent, shallow depth of field  
**Style anchors:** realistic, cinematic, precise anatomy, film grain subtle

## Base
[subject], [wardrobe era + texture], [action], [emotion],
[location], [time of day], [lighting spec], [camera angle]

## Examples
- Duke Johnson stands in rain under a neon sign, trench coat and fedora, jaw set, 1940s Chicago alley, midnight, hard backlight + practical neons, low-angle, realistic cinematic, film grain, 16:9
- King Kushta strides through desert fire, linen armor, resolute, dunes and ash, twilight, volumetric light shafts, telephoto compression, 16:9

## Negative Prompts
blurry, extra limbs, deformed hands, over-saturated, cartoonish, low-res

## Notes
- Keep seed, steps, cfg, model, and LoRAs in a paired JSON for reproducibility.
- Reuse **character LoRAs** for continuity.
