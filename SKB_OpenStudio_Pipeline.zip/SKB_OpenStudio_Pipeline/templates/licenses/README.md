# Media Licensing Guidance

- Code/configs: MIT (see root LICENSE).
- Original images/audio/video by SKBproductions: **All Rights Reserved** by default.
- Third-party SFX/music: store license proof files here.
