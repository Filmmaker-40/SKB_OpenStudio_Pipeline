# Shot-to-Edit Checklist

- [ ] Script page and scene number labeled
- [ ] Storyboard timing locked
- [ ] Prompt + seed saved next to each image
- [ ] Lighting notes (key/fill/rim ratios)
- [ ] Camera path exported from Blender
- [ ] Audio: VO cleaned, noise reduced
- [ ] Color: LUT applied + exposure matched
- [ ] Export: 4K master + 1080p upload
- [ ] HandBrake: web-optimized, AAC audio
- [ ] Upload to YouTube + Pinterest with title/desc templates
