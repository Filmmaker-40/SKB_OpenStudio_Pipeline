# Project Notes

## Logline
(Write your short, compelling logline here.)

## Visual Bible
- Character palette, wardrobe, key references
- Lighting motifs and LUT references

## Pipeline for this project
Script → Storyboarder → DiffusionBee/ComfyUI → Blender → AnimateDiff/Runway/Pika → Kdenlive/DaVinci → Audacity/Ardour → HandBrake → Distribution

## Milestones
- [ ] Episode outline
- [ ] Key art stills
- [ ] First motion test
- [ ] Teaser cut
- [ ] Final cut
