# Upload Instructions (GitHub Web)

1. Create a repo named `SKB_OpenStudio_Pipeline`.
2. Click **Add file → Upload files**.
3. Drag the entire contents of this folder into the browser window.
4. Commit changes.
5. (Optional) Set the repo to Private until you're ready to share.
